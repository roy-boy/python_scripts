"""requester.py module sends POST resuest to API ENDPOINT and gets response back"""
import requests


def send_payload(endpoint_url, payload_string):
    res = requests.post(url=endpoint_url, data=payload_string)
    # res = requests.get(url=endpoint_url)
    api_response = res.text
    print(api_response)
    return api_response
